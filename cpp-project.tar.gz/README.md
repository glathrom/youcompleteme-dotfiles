# vscode-hello-cross-compile

This is my attemp to create a cross compile archive using vscode.