#include <iostream>


int main(int argc, char **argv){

    std::cout << "Hello World!" << std::endl;

    return 0;
}